<!DOCTYPE html>
<html>
<head>
    <title>Inicio</title>
</head>
<body>
    <h1>Bienvenido al sistema 🍽️</h1>
    <p>Selecciona una opción:</p>
    <ul>
        <li><a href="{{ route('login') }}">Iniciar sesión</a></li>
        <li><a href="{{ route('registro') }}">Registrarse</a></li>
        <li><a href="{{ route('productos.invitado') }}">Ver productos</a></li>
    </ul>
</body>
</html>
